from .wiki_reader import WikiReader
from .reddit_reader import RedditReader
from .capitolwords import CapitolWords
from .supremecourt import SupremeCourt
